import { Controller } from '@nestjs/common';

@Controller('transactions')
export class TransactionsController {}
